this code is being kept around to try to keep wheels from being reinvented later

but it really is tailored to the old helper binary that can no longer be built via this code
