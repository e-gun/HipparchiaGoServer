package main

import (
	"database/sql"
	"fmt"
	"log"
	_ "modernc.org/sqlite"
	"os"
	"strings"
	"time"
)

// note that sqlite can't do regex:
// The REGEXP operator is a special syntax for the regexp() user function. No regexp() user function is defined by
// default and so use of the REGEXP operator will normally result in an error message. If an application-defined SQL
// function named "regexp" is added at run-time, then the "X REGEXP Y" operator will be implemented as a call to "regexp(Y,X)".

// slow:
//[HGS] entering selftest mode (3 segments)
//[HGS] [I] 6 search tests
//[HGS] [A1: 2.328s][Δ: 2.328s] single word in corpus: 'vervex'
// postgresql can do this in .211s

// the below will only do simple queries, no windowing, etc


const (
	AUTHORS = `
	CREATE TABLE authors
	(
	  universalid character(6),
	  language character varying(10),
	  idxname character varying(128),
	  akaname character varying(128),
	  shortname character varying(128),
	  cleanname character varying(128),
	  genres character varying(512),
	  recorded_date character varying(64),
	  converted_date integer,
	  location character varying(128)
	)`

	WORKS = `
	CREATE TABLE works
	(
	  universalid character(10),
	  title character varying(512),
	  language character varying(10),
	  publication_info text,
	  levellabels_00 character varying(64),
	  levellabels_01 character varying(64),
	  levellabels_02 character varying(64),
	  levellabels_03 character varying(64),
	  levellabels_04 character varying(64),
	  levellabels_05 character varying(64),
	  workgenre character varying(32),
	  transmission character varying(32),
	  worktype character varying(32),
	  provenance character varying(64),
	  recorded_date character varying(64),
	  converted_date integer,
	  wordcount integer,
	  firstline integer,
	  lastline integer,
	  authentic boolean
	)
	`

	DICTIONARYG = `
	CREATE TABLE greek_dictionary (
    entry_name character varying(256),
    metrical_entry character varying(256),
    unaccented_entry character varying(256),
    id_number real,
    pos character varying(64),
    translations text,
    entry_body text
	)
	`

	DICTIONARYL = `
	CREATE TABLE latin_dictionary (
    entry_name character varying(256),
    metrical_entry character varying(256),
    id_number real,
    entry_key character varying(64),
    pos character varying(64),
    translations text,
    entry_body text
	)
	`

	LEMMATA = `
	CREATE TABLE %s_lemmata
	(
	  dictionary_entry character varying(64),
	  xref_number integer,
	  derivative_forms text
	)`

	MORPHOLOGY = `
	CREATE TABLE %s_morphology
	(
	  observed_form character varying(64),
	  xrefs character varying(128),
	  prefixrefs character varying(128),
	  possible_dictionary_forms jsonb,
	  related_headwords character varying(256)
	)`

	ONEAUTHORTABLE = `
	CREATE TABLE %s (
    "index" integer NOT NULL,
    wkuniversalid character varying(10),
    level_05_value character varying(64),
    level_04_value character varying(64),
    level_03_value character varying(64),
    level_02_value character varying(64),
    level_01_value character varying(64),
    level_00_value character varying(64),
    marked_up_line text,
    accented_line text,
    stripped_line text,
    hyphenated_words character varying(128),
    annotations character varying(256)
	)`

	SQLITEDB = "hgs_sqlite.db"

	// supplements to buildquery.go

	SLITEASLB = `
		( SELECT * FROM
			( SELECT wkuniversalid, index, level_05_value, level_04_value, level_03_value, level_02_value, level_01_value, level_00_value, marked_up_line, accented_line, stripped_line, hyphenated_words, annotations,
				%s || ' ' || lead(%s) ) AS linebundle`
	SLITETB  = `{{ .AU }} WHERE instr({{ .COL }}, '{{ .SK }}') ORDER BY index ASC LIMIT {{ .LIM }}`
	SLITETBX = `{{ .AU }} WHERE instr({{ .COL }}, '{{ .SK }}') AND ({{ .IDX }}) ORDER BY index ASC LIMIT {{ .LIM }}`
	SLITEWB  = ` FROM {{ .AU }} ) first
			) second WHERE instr(second.linebundle, '{{ .SK }}') ORDER BY index ASC LIMIT {{ .LIM }}`
	SLITETWX = ` FROM {{ .AU }} ) first
			) second WHERE instr(second.linebundle, '{{ .SK }}') ORDER BY index ASC LIMIT {{ .LIM }}`
	SLITETT = ` {{ .AU }} WHERE EXISTS
		(SELECT 1 FROM {{ .AU }}_includelist_{{ .TTN }} incl WHERE incl.includeindex = {{ .AU }}.index AND instr({{ .COL }}, '{{ .SK }}')) LIMIT {{ .LIM }}`
	SLITWTT = ` FROM {{ .AU }} WHERE EXISTS
			(SELECT 1 FROM {{ .AU }}_includelist_{{ .TTN }} incl WHERE incl.includeindex = {{ .AU }}.index ) 
			) first
		) second WHERE instr(second.linebundle , '{{ .SK }}') LIMIT {{ .LIM }}`
)

type SQLiteRepository struct {
	db *sql.DB
}

func NewSQLiteRepository(db *sql.DB) *SQLiteRepository {
	return &SQLiteRepository{
		db: db,
	}
}

func (r *SQLiteRepository) Initialize() {
	qq := []string{AUTHORS, WORKS, DICTIONARYG, DICTIONARYL,
		fmt.Sprintf(LEMMATA, "greek"), fmt.Sprintf(LEMMATA, "latin"),
		fmt.Sprintf(MORPHOLOGY, "greek"), fmt.Sprintf(MORPHOLOGY, "latin")}
	for _, q := range qq {
		_, err := r.db.Exec(q)
		if err != nil {
			log.Fatal(err)
		}
	}

	for _, a := range AllAuthors {
		_, err := r.db.Exec(fmt.Sprintf(ONEAUTHORTABLE, a.UID))
		if err != nil {
			log.Fatal(err)
		}
	}

	fmt.Println("SQLiteRepository initialized")
	return
}

func (r *SQLiteRepository) Migrate() error {
	query := ""
	_, err := r.db.Exec(query)
	return err
}

func initializesqlite() {
	start := time.Now()
	e := os.Remove(SQLITEDB)
	if e != nil {
		fmt.Println("remove failed")
	}

	db, err := sql.Open("sqlite", SQLITEDB)
	if err != nil {
		log.Fatal(err)
	}

	rep := NewSQLiteRepository(db)
	rep.Initialize()

	previous := time.Now()
	TimeTracker("A1", fmt.Sprintf("initializesqlite(): SQLiteRepository created"), start, previous)
	previous = time.Now()

	var q string
	for _, a := range AllAuthors {
		q = `INSERT INTO authors (universalid, language, idxname, akaname, shortname, cleanname, genres, recorded_date, converted_date, location) `
		q += `VALUES (?,?,?,?,?,?,?,?,?,?)`
		_, err = rep.db.Exec(q, a.UID, a.Language, a.IDXname, a.Name, a.Shortname, a.Cleaname, a.Genres, a.RecDate, a.ConvDate, a.Location)
		if err != nil {
			fmt.Println("insert author failed")
			panic(err)
		}
	}

	TimeTracker("A2", fmt.Sprintf("initializesqlite(): inserted all authors"), start, previous)
	previous = time.Now()

	qt := `
    INSERT INTO %s ("index", wkuniversalid, level_05_value, level_04_value, level_03_value, level_02_value, level_01_value, level_00_value, 
                    marked_up_line, accented_line, stripped_line, hyphenated_words, annotations)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`

	count := 0
	for _, a := range AllAuthors {
		srch := BuildHollowSearch()
		srch.SearchIn.Authors = []string{a.UID}
		SSBuildQueries(&srch)
		srch.IsActive = true
		srch.TableSize = len(srch.Queries)
		srch = HGoSrch(srch)

		//if !strings.Contains(a.UID, "lt") {
		//	continue
		//}
		//if count > 200 {
		//	break
		//}
		count += 1

		// next is slow; could be faster...
		// [HGS] initialization took 13571.294s before reaching StartEchoServer()
		// https://stackoverflow.com/questions/12486436/how-do-i-batch-sql-statements-with-package-database-sql
		for i := 0; i < len(srch.Results); i++ {
			r := srch.Results[i]
			ins := fmt.Sprintf(qt, a.UID)
			_, err = rep.db.Exec(ins, r.TbIndex, r.WkUID, r.Lvl5Value, r.Lvl4Value, r.Lvl3Value, r.Lvl2Value, r.Lvl1Value, r.Lvl0Value, r.MarkedUp, r.Accented, r.Stripped, r.Hyphenated, r.Annotations)
			if err != nil {
				fmt.Println("insert line into author table failed")
				panic(err)
			}
		}
		msg(fmt.Sprintf("[%d of %d] %s - %s inserted", count, len(AllAuthors), a.UID, a.Name), 2)
	}

}

func samplequery() {
	db, err := sql.Open("sqlite", SQLITEDB)
	if err != nil {
		log.Fatal(err)
	}
	rep := NewSQLiteRepository(db)
	q := `SELECT stripped_line from lt1212 where instr(stripped_line, 'quemquam') LIMIT 100;`
	rows, err := rep.db.Query(q)
	if err != nil {
		fmt.Println("select failed")
		panic(err)
	}

	msg(q, 1)
	for rows.Next() {
		var c string
		e := rows.Scan(&c)
		if e != nil {
			log.Fatal(e)
		}
		fmt.Println(c)
	}
}

func SQLiteWorklineQuery(prq PrerolledQuery, dbconn *sql.DB) []DbWorkline {

	// [a] build a temp table if needed

	if prq.TempTable != "" {
		_, err := dbconn.Exec(prq.TempTable)
		chke(err)
	}

	// [b] execute the main query (nb: query needs to satisfy needs of RowToStructByPos in [c])

	prq.PsqlQuery = strings.ReplaceAll(prq.PsqlQuery, `wkuniversalid, index,`, `wkuniversalid, "index",`)
	prq.PsqlQuery = strings.ReplaceAll(prq.PsqlQuery, `ORDER BY index`, `ORDER BY "index"`)
	prq.PsqlQuery = strings.ReplaceAll(prq.PsqlQuery, `index BETWEEN`, `"index" BETWEEN`)

	foundrows, err := dbconn.Query(prq.PsqlQuery)
	// chke(err)
	if err != nil {
		msg("query yielded error", 0)
		msg(prq.PsqlQuery, 1)
		panic(err)
	}

	// [c] convert the finds into []DbWorkline

	var thesefinds []DbWorkline
	for foundrows.Next() {
		var f DbWorkline
		e := foundrows.Scan(&f.WkUID, &f.TbIndex, &f.Lvl5Value, &f.Lvl4Value, &f.Lvl3Value, &f.Lvl2Value,
			&f.Lvl1Value, &f.Lvl0Value, &f.MarkedUp, &f.Accented, &f.Stripped, &f.Hyphenated, &f.Annotations)
		chke(e)
		thesefinds = append(thesefinds, f)
	}
	chke(err)

	return thesefinds
}

// https://turriate.com/articles/making-sqlite-faster-in-go

type LitePool struct {
	Connections chan *sql.DB
}

func (p *LitePool) Initialize() {
	for i := 0; i < Config.WorkerCount; i++ {
		conn, err := sql.Open("sqlite", SQLITEDB)
		chke(err)
		p.Connections <- conn
	}
}

func (p *LitePool) Checkout() *sql.DB {
	return <-p.Connections
}

func (p *LitePool) Checkin(c *sql.DB) {
	p.Connections <- c
}

// FillSQLItePool -
func FillSQLItePool() *LitePool {
	c := make(chan *sql.DB, Config.WorkerCount)
	p := &LitePool{
		Connections: c,
	}
	p.Initialize()
	msg("LitePool filled", 2)
	return p
}

